
/*
 * Example11_12.c
 *
 * Created: 05/08/2017 03:32:41
 *  Author: Naimi
 */ 


#include <avr/io.h>    		
int main (void)
{
	DDRC = 0xFF;				//Port C is output
	UCSR0B = (1<<RXEN0);		//initialize USART0
	UCSR0C = (1<< UCSZ01)|(1<<UCSZ00);
	UBRR0L = 103;
	
	while(1)
	{
		while (! (UCSR0A & (1<<RXC0))); 	//wait until new data
		PORTC = UDR0;
	}
	return 0;
}