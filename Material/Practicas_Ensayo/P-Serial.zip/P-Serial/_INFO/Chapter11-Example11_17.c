
/*
 * Example11_17.c
 *
 * Created: 05/08/2017 04:41:41 
 *  Author: Naimi
 */ 


#include <avr/io.h>
#include <avr/interrupt.h>

ISR(USART_RX_vect)
{
	PORTB = UDR0;
}

int main (void)
{
	DDRB = 0xFF;				//make Port B an output

	UCSR0B = (1<<RXEN0)|(1<<RXCIE0);//enable receive and RXC int.
	UCSR0C = (1<< UCSZ01)|(1<<UCSZ00);
	UBRR0L = 103;
	
	sei();				//enable interrupts
	
	while (1);			//wait forever
}