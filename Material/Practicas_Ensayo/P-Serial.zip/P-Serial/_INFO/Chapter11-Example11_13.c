
/*
 * Example11_13.c
 *
 * Created: 05/08/2017 03:37:52 
 *  Author: Naimi
 */ 

#include <avr/io.h>    		
int main (void)
{
	UCSR0B = (1<<TXEN0)|(1<<RXEN0);		//initialize USART0
	UCSR0C = (1<< UCSZ01)|(1<<UCSZ00);
	UBRR0L = 103;
	
	unsigned char ch;
	
	while(1)
	{
		while (! (UCSR0A & (1<<RXC0))); 	//wait until new data
		
		ch = UDR0;

	    if (ch >= 'a' && ch<='z')
		{
			ch += ('A'-'a');
			while (! (UCSR0A & (1<<UDRE0)));
			UDR0 = ch;
		}		
	}
	return 0;
}