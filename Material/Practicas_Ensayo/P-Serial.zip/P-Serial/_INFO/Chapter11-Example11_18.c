
/*
 * Example11_18.c
 *
 * Created: 05/08/2017 04:48:08 
 *  Author: Naimi
 */ 


#include <avr/io.h>
#include <avr/interrupt.h>
ISR(USART_UDRE_vect)
{
	UDR0 = 'G';
}

int main (void)
{
	UCSR0B = (1<<TXEN0)|(1<<UDRIE0);
	UCSR0C = (1<< UCSZ01)|(1<<UCSZ00);
	UBRR0L = 103;

	sei();				//enable interrupts
	while (1);			//wait forever
	return 0;
}