
/*
 * Example11_10.c
 *
 * Created: 04/26/2017 10:28:23 
 *  Author: Naimi
 */ 


#include <avr/io.h>    			
#define F_CPU 16000000UL
#define BAUD_RATE 9600

void usart_init (void)
{
	UCSR0B = (1<<TXEN0);
	UCSR0C = (1<< UCSZ01)|(1<<UCSZ00);
	UBRR0L = F_CPU/16/BAUD_RATE-1; //UBRR0L = 103;	
}

void usart_send (unsigned char ch)
{							
	while (! (UCSR0A & (1<<UDRE0))); 	//wait until UDR0 is empty
	UDR0 = ch;					//transmit ch
}

int main (void)
{
	usart_init();				//initialize the USART
	
	while(1)					//do forever
		usart_send ('G');		//transmit ‘G’ letter

	return 0;
}
